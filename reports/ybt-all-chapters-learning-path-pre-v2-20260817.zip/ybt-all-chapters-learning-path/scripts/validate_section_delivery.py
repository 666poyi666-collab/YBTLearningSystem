#!/usr/bin/env python3
"""Fail-closed validator for parallel 一本通 Luna section deliveries."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any


SCHEMA = "ybt-luna-section-delivery-v1"
MODEL = "gpt-5.6-luna"
EFFORT = "max"
PERSONAS = {
    "literal-zero-base",
    "recognition-weak",
    "algebra-weak",
    "visual-weak",
    "self-check-weak",
}
ITEM_FIELDS = {
    "item_key",
    "ordinal",
    "kind",
    "label",
    "cycle_sequence",
    "position",
    "course_refs",
    "knowledge_refs",
    "type_refs",
    "recognition_cues",
    "method_model",
    "first_written_line_template",
    "continuation_actions",
    "likely_blockers",
    "minimal_correction_prompts",
    "independent_self_checks",
    "visual_dependency",
    "route_version",
}
FORBIDDEN_KEYS = {
    "question_text",
    "teaching_text",
    "solution",
    "solution_text",
    "answer",
    "answer_text",
    "correct_option",
    "final_answer",
}
ANSWER_LEAK_RE = re.compile(
    r"(?:答案\s*[：:]|正确选项|应选\s*[A-F]|故选\s*[A-F]|最终答案|"
    r"answer_text|correct_option|final_answer|solution_text)",
    re.I,
)


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def section_folder(section: str) -> str:
    return section.replace("+", "_")


def canonical_items(project_root: Path, section: str) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    packet_path = project_root / "data" / "packets" / section_folder(section) / "learning_packet.json"
    packet = load_json(packet_path)
    if packet.get("section") != section:
        raise ValueError(f"section mismatch in {packet_path}")
    canonical: dict[str, dict[str, Any]] = {}
    for item in packet.get("worked_examples", []):
        canonical[f"LI:{item['item_id']}"] = item
    for item in packet.get("direct_variants", []):
        key = f"LI:{item['item_id']}"
        if key in canonical:
            raise ValueError(f"duplicate canonical item in {section}: {key}")
        canonical[key] = item
    for item in packet.get("exercise_questions", []):
        key = f"Q:{item['qid']}"
        if key in canonical:
            raise ValueError(f"duplicate canonical item in {section}: {key}")
        canonical[key] = item
    hashes = {
        "learning_packet_sha256": sha256_file(packet_path),
        "packet_sha256": sha256_file(packet_path.parent / "packet.json"),
    }
    return canonical, hashes


def _walk_forbidden_keys(value: Any, path: str = "delivery") -> list[str]:
    errors: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in FORBIDDEN_KEYS:
                errors.append(f"forbidden key at {path}.{key}")
            errors.extend(_walk_forbidden_keys(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            errors.extend(_walk_forbidden_keys(child, f"{path}[{index}]"))
    return errors


def validate_assignment(project_root: Path, assignment: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    tasks = assignment.get("tasks")
    if not isinstance(tasks, list) or not tasks:
        return ["assignment has no tasks"]
    task_ids = [str(task.get("task_id") or "") for task in tasks]
    if len(task_ids) != len(set(task_ids)) or any(not task_id for task_id in task_ids):
        errors.append("assignment task IDs are empty or duplicated")
    seen_sections: Counter[str] = Counter()
    delivered_total = 0
    for task in tasks:
        sections = task.get("sections") or []
        expected = 0
        for section in sections:
            seen_sections[str(section)] += 1
            try:
                canonical, _ = canonical_items(project_root, str(section))
            except Exception as exc:
                errors.append(f"{task.get('task_id')} cannot load {section}: {exc}")
                continue
            expected += len(canonical)
        if int(task.get("expected_items", -1)) != expected:
            errors.append(
                f"{task.get('task_id')} expected_items={task.get('expected_items')} but canonical={expected}"
            )
        delivered_total += expected
    duplicates = sorted(section for section, count in seen_sections.items() if count != 1)
    if duplicates:
        errors.append(f"sections missing or duplicated inside assignment: {duplicates}")
    report_path = project_root / "reports" / "all_chapters" / "packet-build-current.json"
    report = load_json(report_path)
    expected_sections = {str(row["section"]) for row in report.get("sections", [])}
    assigned_sections = set(seen_sections)
    if assigned_sections != expected_sections:
        errors.append(
            f"assignment section set mismatch missing={sorted(expected_sections-assigned_sections)} "
            f"unexpected={sorted(assigned_sections-expected_sections)}"
        )
    expected_total = int((report.get("actual") or {}).get("total_numbered_learning_items", -1))
    if delivered_total != expected_total:
        errors.append(f"assignment item total={delivered_total} but report={expected_total}")
    return errors


def _require_nonempty_list(item: dict[str, Any], key: str, errors: list[str], prefix: str) -> None:
    value = item.get(key)
    if not isinstance(value, list) or not value:
        errors.append(f"{prefix}.{key} must be a non-empty list")


def validate_item(
    item: dict[str, Any],
    source: dict[str, Any],
    course_keys: set[str],
    prefix: str,
) -> list[str]:
    errors: list[str] = []
    missing = sorted(ITEM_FIELDS - set(item))
    if missing:
        errors.append(f"{prefix} missing fields {missing}")
    if item.get("kind") not in {"worked_example", "direct_variant", "abc_exercise"}:
        errors.append(f"{prefix}.kind is invalid")
    _require_nonempty_list(item, "course_refs", errors, prefix)
    _require_nonempty_list(item, "recognition_cues", errors, prefix)
    _require_nonempty_list(item, "continuation_actions", errors, prefix)
    _require_nonempty_list(item, "likely_blockers", errors, prefix)
    _require_nonempty_list(item, "minimal_correction_prompts", errors, prefix)
    _require_nonempty_list(item, "independent_self_checks", errors, prefix)
    unknown_courses = sorted(set(item.get("course_refs") or []) - course_keys)
    if unknown_courses:
        errors.append(f"{prefix} references unknown courses {unknown_courses}")
    if not str(item.get("method_model") or "").strip():
        errors.append(f"{prefix}.method_model is empty")
    if not str(item.get("first_written_line_template") or "").strip():
        errors.append(f"{prefix}.first_written_line_template is empty")
    visual = item.get("visual_dependency")
    if not isinstance(visual, dict):
        errors.append(f"{prefix}.visual_dependency is missing")
    else:
        expected_visual = source.get("visual_status")
        if visual.get("status") != expected_visual:
            errors.append(
                f"{prefix}.visual status={visual.get('status')} but packet={expected_visual}"
            )
    serialized = json.dumps(item, ensure_ascii=False)
    if ANSWER_LEAK_RE.search(serialized):
        errors.append(f"{prefix} contains answer/solution leakage")
    errors.extend(_walk_forbidden_keys(item, prefix))
    return errors


def validate_simulation(section: dict[str, Any], item_keys: set[str]) -> list[str]:
    errors: list[str] = []
    simulation = section.get("simulation")
    if not isinstance(simulation, dict):
        return [f"{section.get('section')} simulation missing"]
    rounds = simulation.get("rounds")
    if not isinstance(rounds, list) or len(rounds) != 5:
        return [f"{section.get('section')} simulation must have five rounds"]
    if sorted(row.get("round") for row in rounds) != [1, 2, 3, 4, 5]:
        errors.append(f"{section.get('section')} round numbers are invalid")
    attempt_counts: Counter[str] = Counter()
    for round_row in rounds:
        round_number = round_row.get("round")
        personas = round_row.get("personas")
        if not isinstance(personas, list) or len(personas) != 5:
            errors.append(f"{section.get('section')} round {round_number} must have five personas")
            continue
        profiles = {persona.get("profile") for persona in personas if isinstance(persona, dict)}
        if profiles != PERSONAS:
            errors.append(f"{section.get('section')} round {round_number} persona profiles mismatch")
        persona_ids = [persona.get("persona_id") for persona in personas if isinstance(persona, dict)]
        if len(persona_ids) != len(set(persona_ids)):
            errors.append(f"{section.get('section')} round {round_number} persona IDs duplicated")
        for persona in personas:
            results = persona.get("item_results") if isinstance(persona, dict) else None
            if not isinstance(results, list):
                errors.append(f"{section.get('section')} round {round_number} persona results missing")
                continue
            keys = [str(result.get("item_key") or "") for result in results if isinstance(result, dict)]
            if len(keys) != len(set(keys)) or set(keys) != item_keys:
                errors.append(
                    f"{section.get('section')} round {round_number} persona item coverage mismatch"
                )
            for result in results:
                key = str(result.get("item_key") or "")
                attempt_counts[key] += 1
                for field in (
                    "recognized_method",
                    "first_line_written",
                    "continuation_complete",
                    "self_check_complete",
                ):
                    if not isinstance(result.get(field), bool):
                        errors.append(
                            f"{section.get('section')} round {round_number} {key}.{field} must be boolean"
                        )
                if round_number == 5:
                    if not all(
                        result.get(field) is True
                        for field in (
                            "recognized_method",
                            "first_line_written",
                            "continuation_complete",
                            "self_check_complete",
                        )
                    ):
                        errors.append(f"{section.get('section')} round 5 item failed: {key}")
                    if result.get("verdict") not in {"passed", "passed_after_self_correction"}:
                        errors.append(f"{section.get('section')} round 5 verdict failed: {key}")
        if round_number == 5 and round_row.get("route_hash") != section.get("final_route_hash"):
            errors.append(f"{section.get('section')} round 5 route hash is stale")
    wrong_counts = sorted(key for key in item_keys if attempt_counts[key] != 25)
    if wrong_counts:
        errors.append(f"{section.get('section')} items do not have 25 attempts: {wrong_counts}")
    if simulation.get("status") != "passed":
        errors.append(f"{section.get('section')} simulation status is not passed")
    return errors


def validate_delivery(
    project_root: Path,
    assignment: dict[str, Any],
    task_id: str,
    delivery: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    task = next((row for row in assignment.get("tasks", []) if row.get("task_id") == task_id), None)
    if task is None:
        return [f"unknown task_id: {task_id}"]
    if assignment.get("status") != "ready":
        errors.append("assignment is not ready")
    if delivery.get("schema_version") != SCHEMA:
        errors.append("delivery schema mismatch")
    if delivery.get("task_id") != task_id:
        errors.append("delivery task_id mismatch")
    model = delivery.get("model_contract") or {}
    if model.get("model") != MODEL or model.get("reasoning_effort") != EFFORT:
        errors.append("delivery model contract is not gpt-5.6-luna + max")
    assigned = [str(value) for value in task.get("sections", [])]
    if [str(value) for value in delivery.get("assigned_sections", [])] != assigned:
        errors.append("assigned section order mismatch")
    catalog_path = project_root / "data" / "all_chapters_course_catalog.json"
    catalog = load_json(catalog_path)
    course_keys = {str(row.get("course_key")) for row in catalog.get("courses", [])}
    sections = delivery.get("sections")
    if not isinstance(sections, list):
        return errors + ["delivery sections missing"]
    by_section = {str(row.get("section")): row for row in sections if isinstance(row, dict)}
    if set(by_section) != set(assigned) or len(by_section) != len(sections):
        errors.append("delivery section set missing, duplicated, or unexpected")
    all_delivered_keys: list[str] = []
    for section_id in assigned:
        section = by_section.get(section_id)
        if section is None:
            continue
        canonical, expected_hashes = canonical_items(project_root, section_id)
        source_binding = section.get("source_binding") or {}
        for key, expected in expected_hashes.items():
            if source_binding.get(key) != expected:
                errors.append(f"{section_id} {key} is stale")
        items = section.get("items")
        if not isinstance(items, list):
            errors.append(f"{section_id} items missing")
            continue
        keys = [str(item.get("item_key") or "") for item in items if isinstance(item, dict)]
        if len(keys) != len(set(keys)):
            errors.append(f"{section_id} duplicate delivery item keys")
        if set(keys) != set(canonical):
            errors.append(
                f"{section_id} item mismatch missing={sorted(set(canonical)-set(keys))} "
                f"unexpected={sorted(set(keys)-set(canonical))}"
            )
        all_delivered_keys.extend(keys)
        signatures: Counter[str] = Counter()
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                errors.append(f"{section_id} item {index} is not an object")
                continue
            key = str(item.get("item_key") or "")
            source = canonical.get(key)
            if source is None:
                continue
            errors.extend(validate_item(item, source, course_keys, f"{section_id}.items[{index}]"))
            signatures[
                json.dumps(
                    [
                        item.get("recognition_cues"),
                        item.get("method_model"),
                        item.get("first_written_line_template"),
                        item.get("likely_blockers"),
                        item.get("independent_self_checks"),
                    ],
                    ensure_ascii=False,
                    sort_keys=True,
                )
            ] += 1
        if len(items) >= 6 and signatures:
            generic_limit = max(5, math.ceil(len(items) * 0.75))
            if max(signatures.values()) >= generic_limit:
                errors.append(f"{section_id} method records are excessively generic")
        errors.extend(validate_simulation(section, set(canonical)))
        coverage = section.get("coverage") or {}
        if coverage.get("expected_items") != len(canonical) or coverage.get("delivered_items") != len(canonical):
            errors.append(f"{section_id} coverage counts mismatch")
        if section.get("status") != "passed":
            errors.append(f"{section_id} status is not passed")
    if len(all_delivered_keys) != int(task.get("expected_items", -1)):
        errors.append("task delivered item count mismatch")
    coverage = delivery.get("coverage") or {}
    if coverage.get("expected_items") != int(task.get("expected_items", -1)):
        errors.append("top-level expected_items mismatch")
    if coverage.get("delivered_items") != int(task.get("expected_items", -1)):
        errors.append("top-level delivered_items mismatch")
    for key in ("duplicate_items", "missing_items", "unexpected_items"):
        if coverage.get(key) != []:
            errors.append(f"top-level {key} must be empty")
    if delivery.get("proxy_simulation") != "passed":
        errors.append("proxy_simulation is not passed")
    for key in ("independent_acceptance", "human_acceptance", "cold_24h_retest"):
        if delivery.get(key) != "not_run":
            errors.append(f"{key} must remain not_run in a section-owner delivery")
    if delivery.get("status") != "passed":
        errors.append("delivery status is not passed")
    errors.extend(_walk_forbidden_keys(delivery))
    return sorted(set(errors))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--assignment", required=True)
    parser.add_argument("--task-id")
    parser.add_argument("--delivery")
    parser.add_argument("--assignment-only", action="store_true")
    args = parser.parse_args()
    project_root = Path(args.project_root).resolve()
    assignment_path = Path(args.assignment)
    if not assignment_path.is_absolute():
        assignment_path = project_root / assignment_path
    assignment = load_json(assignment_path)
    errors = validate_assignment(project_root, assignment)
    if not args.assignment_only:
        if not args.task_id or not args.delivery:
            parser.error("--task-id and --delivery are required unless --assignment-only is used")
        delivery_path = Path(args.delivery)
        if not delivery_path.is_absolute():
            delivery_path = project_root / delivery_path
        delivery = load_json(delivery_path)
        errors.extend(validate_delivery(project_root, assignment, args.task_id, delivery))
    report = {
        "status": "passed" if not errors else "failed",
        "assignment": str(assignment_path),
        "task_id": args.task_id,
        "errors": sorted(set(errors)),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
