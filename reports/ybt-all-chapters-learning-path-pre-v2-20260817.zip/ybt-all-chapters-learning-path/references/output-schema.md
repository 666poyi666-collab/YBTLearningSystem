# Delivery Output Schema

## Contents

1. Required files
2. `delivery.json`
3. Item method record
4. Simulation record
5. Markdown and HTML requirements
6. Evidence file

## 1. Required Files

Each assignment writes only:

```text
reports/luna_sections/<task_id>/
  delivery.json
  learning_path_without_questions.md
  learning_path_without_questions.html
  evidence.md
  shared_defects.json          # only when defects exist
```

## 2. `delivery.json`

Required top-level shape:

```json
{
  "schema_version": "ybt-luna-section-delivery-v1",
  "task_id": "LUNA-YBT-01",
  "model_contract": {
    "model": "gpt-5.6-luna",
    "reasoning_effort": "max",
    "context_window": 1050000
  },
  "assigned_sections": ["..."],
  "source_binding": {
    "ready_sha256": "...",
    "packet_build_sha256": "...",
    "course_catalog_sha256": "...",
    "vision_sidecar_sha256": "..."
  },
  "sections": [],
  "coverage": {
    "expected_items": 0,
    "delivered_items": 0,
    "duplicate_items": [],
    "missing_items": [],
    "unexpected_items": []
  },
  "proxy_simulation": "passed",
  "independent_acceptance": "not_run",
  "human_acceptance": "not_run",
  "cold_24h_retest": "not_run",
  "status": "passed"
}
```

Each section contains:

```json
{
  "section": "2.1",
  "label": "第1节 ...",
  "source_binding": {
    "packet_sha256": "...",
    "learning_packet_sha256": "...",
    "transcript_sha256": ["..."],
    "image_sha256": ["..."]
  },
  "overview": {
    "first_course": "exact catalog course_key",
    "new_courses_in_section_order": [],
    "already_learned_dependencies": [],
    "item_labels_in_order": []
  },
  "route_versions": [],
  "final_route_hash": "...",
  "cycles": [],
  "items": [],
  "simulation": {},
  "coverage": {},
  "status": "passed"
}
```

## 3. Item Method Record

Every canonical item appears exactly once:

```json
{
  "item_key": "LI:<item_id> or Q:<qid>",
  "ordinal": 1,
  "kind": "worked_example|direct_variant|abc_exercise",
  "label": "教材例1 or A1",
  "cycle_sequence": 1,
  "position": "知识点右侧例题|直属变式|类型题|A/B/C习题",
  "course_refs": ["exact catalog course_key"],
  "knowledge_refs": ["full descriptive knowledge label"],
  "type_refs": ["full descriptive type label"],
  "recognition_cues": ["..."],
  "method_model": "...",
  "first_written_line_template": "...",
  "continuation_actions": ["..."],
  "likely_blockers": ["..."],
  "minimal_correction_prompts": ["..."],
  "independent_self_checks": ["..."],
  "visual_dependency": {
    "status": "READY_TEXT_ONLY|VISION_VERIFIED|BLOCKED",
    "image_sha256": []
  },
  "route_version": 1
}
```

Rules:

- `course_refs` cannot be empty.
- Use exact course keys from `data/all_chapters_course_catalog.json`.
- Do not include `question_text`, `teaching_text`, `solution`, `answer`, correct options, or solved final values.
- `first_written_line_template` must contain symbols or placeholders derived from the problem form, but must stop before solving.
- Recognition and blockers must be item-specific enough to distinguish neighboring items.
- Do not display `item_key` in learner-facing output.

Cycle shape:

```json
{
  "sequence": 1,
  "title": "...",
  "new_courses": [],
  "already_learned_course_calls": [],
  "knowledge_labels": [],
  "worked_example_keys": [],
  "direct_variant_keys": [],
  "type_example_keys": [],
  "exercise_keys": [],
  "acceptance_checks": []
}
```

## 4. Simulation Record

Required section shape:

```json
{
  "protocol": "five-round-five-persona-v1",
  "rounds": [
    {
      "round": 1,
      "route_version": 1,
      "route_hash": "...",
      "personas": [
        {
          "persona_id": "R1-P1",
          "profile": "literal-zero-base",
          "item_results": [
            {
              "item_key": "LI:...",
              "recognized_method": true,
              "first_line_written": true,
              "continuation_complete": true,
              "self_check_complete": true,
              "first_blocker": null,
              "correction_used": null,
              "verdict": "passed"
            }
          ]
        }
      ],
      "failed_item_keys": [],
      "route_repairs": []
    }
  ],
  "expected_attempts_per_item": 25,
  "actual_attempts_per_item": {},
  "unresolved_item_keys": [],
  "status": "passed"
}
```

Each round has exactly five distinct personas. Each persona has exactly one result for every section item. Later rounds bind the revised route hash. Never copy another persona's answer into a later attempt.

## 5. Markdown and HTML Requirements

The learner-facing route starts with:

1. Section name.
2. First course to hear.
3. Remaining new courses in order.
4. Exact textbook item labels to complete.
5. One-line source and status summary.

For each cycle show:

1. New course, if any.
2. Already learned courses called by this cycle.
3. Knowledge label.
4. Adjacent examples.
5. Direct variants.
6. Type examples.
7. A/B/C items.
8. Cycle checks.

For every item show the seven learner fields, but not question text, answers, internal IDs, hashes, implementation notes, or model instructions.

HTML requirements:

- UTF-8 `<meta charset="utf-8">`.
- Responsive at 360 px and desktop widths.
- No card nesting.
- Restrained work-focused layout.
- Distinguish new course, learned course, worked example, variant, type item, exercise, blocked state, and verification state by accessible color plus text.
- MathJax-compatible LaTeX with balanced delimiters.
- Stable task numbering; dynamic content must not shift controls or labels.

## 6. Evidence File

`evidence.md` records:

- Exact files and hashes consumed.
- Commands run.
- Validator output.
- Coverage totals.
- Simulation counts and route versions.
- Shared defects.
- Final states for proxy simulation, independent acceptance, human acceptance, and 24-hour retest.

Do not paste credentials, full chat transcripts, or answer sidecars.
